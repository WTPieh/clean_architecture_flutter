import 'package:clean_architecture_flutter/core/erorrs/failures.dart';
import 'package:clean_architecture_flutter/features/tasks/domain/usecases/get_tasks.dart';
import 'package:flutter/foundation.dart';
import '../../domain/entities/task.dart';

class TaskProvider extends ChangeNotifier {
  List<Task>? _tasks = [];
  List<Task>? get tasks => _tasks;
  final GetTasksUseCase _getTasks;

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  String? _error;
  String? get error => _error;

  TaskProvider(this._getTasks) {
    loadTasks();
  }

  void loadTasks() async {
    _error = null;
    _isLoading = true;
    notifyListeners();

    try {
      _tasks = await _getTasks.execute();
      notifyListeners();
    } catch (e) {
      if (e is ServerFailure) {
        _error = e.message;
      } else {
        _error = "Unexpected Error, try again.";
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }
}
