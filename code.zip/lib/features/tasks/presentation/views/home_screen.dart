import 'package:clean_architecture_flutter/features/tasks/presentation/provider/tasks_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<TaskProvider>(builder: (context, provider, widget) {
      if (provider.isLoading) {
        return const CircularProgressIndicator();
      }
      if (provider.error != null) {
        return Text(provider.error!);
      }
      if (provider.tasks == null) {
        return const Text("Loading");
      } else if (provider.tasks!.isEmpty) {
        return const Text("No Tasks to render");
      }
      return ListView.builder(
          itemCount: provider.tasks?.length,
          itemBuilder: (context, index) {
            return Text(provider.tasks![index].title);
          });
    });
  }
}
