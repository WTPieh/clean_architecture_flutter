import '../../domain/entities/task.dart';

class TaskModel extends Task {
  const TaskModel(
      {required super.id,
      required super.title,
      required super.isDone,
      required super.createdAt});

  // From JSON (Firebase)
  factory TaskModel.fromJson(Map<String, dynamic> json, String id) {
    return TaskModel(
      id: id,
      title: json['title'] as String,
      isDone: json['isDone'] as bool,
      createdAt: DateTime.parse(json['createdAt'] as String),
    );
  }

  ///
  /// {
  ///   "id": "123456890",
  ///   "title": "Some title",
  ///   "isDone": fasle,
  ///   "createdAt": "2025-09-07"
  /// }
  ///
  ///

  // To JSON (Firebase)
  Map<String, dynamic> toJson() {
    return {
      'title': title,
      'isDone': isDone,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory TaskModel.fromEntity(Task task) {
    return TaskModel(
      id: task.id,
      title: task.title,
      isDone: task.isDone,
      createdAt: task.createdAt,
    );
  }
}
