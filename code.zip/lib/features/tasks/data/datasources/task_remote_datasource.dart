import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/task_model.dart';

abstract class TaskRemoteDataSource {
  Future<List<TaskModel>> getTasks();
  Future<TaskModel> createTask(String title);
  Future<TaskModel> updateTask(TaskModel task);
  Future<void> deleteTask(String id);
}

class TaskRemoteDataSourceImpl implements TaskRemoteDataSource {
  final FirebaseFirestore firestore;

  const TaskRemoteDataSourceImpl(this.firestore);

  @override
  Future<List<TaskModel>> getTasks() async {
    final snapshot = await firestore
        .collection('tasks')
        .orderBy('createdAt', descending: true)
        .get();

    return snapshot.docs
        .map((doc) => TaskModel.fromJson(doc.data(), doc.id))
        .toList();
  }

  @override
  Future<TaskModel> createTask(String title) async {
    final docRef = await firestore.collection('tasks').add({
      'title': title,
      'isDone': false,
      'createdAt': DateTime.now().toIso8601String()
    });

    final doc = await docRef.get();
    return TaskModel.fromJson(doc.data()!, doc.id);
  }

  @override
  Future<TaskModel> updateTask(TaskModel task) async {
    await firestore.collection('tasks').doc(task.id).update(task.toJson());

    final doc = await firestore.collection('tasks').doc(task.id).get();
    return TaskModel.fromJson(doc.data()!, doc.id);
  }

  @override
  Future<void> deleteTask(String id) async {
    await firestore.collection('tasks').doc(id).delete();
  }
}
